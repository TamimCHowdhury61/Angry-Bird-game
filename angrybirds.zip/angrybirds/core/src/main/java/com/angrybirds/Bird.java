package com.angrybirds;

public class Bird {
}
