package com.angrybirds;

public class Pig {
}
